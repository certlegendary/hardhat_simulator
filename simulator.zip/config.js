module.exports = {
    "name": "new",
    "setBlances": [
        {
            "address": "0x3AEff54aa6020A276926B5bfA33c692eFA74A2E3",
            "value": "1"
        },
        {
            "address": "0x5Ef6feE657e19139377Eafa1e30db6b5AB147969",
            "value": "1"
        }
    ],
    "blockNumber": "15791468",
    "tokenAddy": "0x66E83E436d3899B5ACA2C9Cdd90fe06585e0F990",
    "quoteTokenAddy": "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2",
    "simulates": [
        {
            "op_type": "quote_approve",
            "from": "0x6E94987C94AC9A38da64d971Aa8De92913c3FC1D"
        },
        {
            "op_type": "approve",
            "from": "0xE0BbD92e506043B942a25B7DfE6321E6aFFFf9B9"
        },
        {
            "op_type": "addliquidity",
            "from": "0xE0BbD92e506043B942a25B7DfE6321E6aFFFf9B9",
            "token_amount": "80%",
            "eth_amount": "1",
            "gasLimit": "3000000"
        },
        {
            "op_type": "custom",
            "from": "0x53586044d82B47E7B997B13bad3e3D94D8F87df4",
            "to": "0x66E83E436d3899B5ACA2C9Cdd90fe06585e0F990",
            "data": "0x1d97b7cd",
            "value": "0",
            "gasLimit": "200000"
        },
        {
            "op_type": "blockjump",
            "blockjump": "4"
        },
        {
            "op_type": "function_call",
            "function": "setMaxWallet",
            "params": "[true, 1000000000]",
            "gasLimit": "500000"
        },
        {
            "op_type": "blockjump",
            "blockjump": "1"
        },
        {
            "op_type": "fomobuy",
            "from": "0xCE222910bA7524cADc75DDC7c57Ec5b97E8bFfc9",
            "eth_amount": "0.01",
            "gasLimit": "900000"
        },
        {
            "op_type": "limitbuy",
            "from": "0xCE222910bA7524cADc75DDC7c57Ec5b97E8bFfc9",
            "token_amount": "0.9%",
            "eth_amount_max": "0.8",
            "gasLimit": "500000"
        }
    ],
    "start": false
}